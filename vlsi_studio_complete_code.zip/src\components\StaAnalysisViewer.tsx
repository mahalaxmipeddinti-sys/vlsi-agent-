import React, { useState } from 'react';
import { 
  Clock, 
  Activity, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Sliders, 
  Zap, 
  ArrowRight, 
  RefreshCw, 
  Layers,
  ChevronRight,
  Sparkles,
  Award
} from 'lucide-react';

export interface StaPathItem {
  id: string;
  startPoint: string;
  endPoint: string;
  clockDomain: string;
  requiredTimeNs: number;
  arrivalTimeNs: number;
  slackNs: number;
  type: 'setup' | 'hold';
  status: 'MET' | 'VIOLATED';
  logicLevels: number;
  fanoutMax: number;
  criticalNet: string;
}

export function StaAnalysisViewer() {
  const [pvtCorner, setPvtCorner] = useState<'SS_0.9V_125C' | 'TT_1.0V_25C' | 'FF_1.1V_-40C'>('TT_1.0V_25C');
  const [clockPeriodNs, setClockPeriodNs] = useState<number>(2.0); // 500 MHz default
  const [activePathTab, setActivePathTab] = useState<'setup' | 'hold'>('setup');
  const [selectedPathId, setSelectedPathId] = useState<string>('P1');

  // Simulated STA timing paths based on corner and target clock period
  const setupPaths: StaPathItem[] = [
    {
      id: 'P1',
      startPoint: 'reg_a_q_reg/CLK',
      endPoint: 'alu_out_reg/D',
      clockDomain: 'clk_core (500MHz)',
      requiredTimeNs: clockPeriodNs * 0.92,
      arrivalTimeNs: Number((clockPeriodNs * 0.78 * (pvtCorner === 'SS_0.9V_125C' ? 1.18 : pvtCorner === 'FF_1.1V_-40C' ? 0.85 : 1.0)).toFixed(3)),
      slackNs: Number(((clockPeriodNs * 0.92) - (clockPeriodNs * 0.78 * (pvtCorner === 'SS_0.9V_125C' ? 1.18 : pvtCorner === 'FF_1.1V_-40C' ? 0.85 : 1.0))).toFixed(3)),
      type: 'setup',
      status: ((clockPeriodNs * 0.92) - (clockPeriodNs * 0.78 * (pvtCorner === 'SS_0.9V_125C' ? 1.18 : pvtCorner === 'FF_1.1V_-40C' ? 0.85 : 1.0))) >= 0 ? 'MET' : 'VIOLATED',
      logicLevels: 6,
      fanoutMax: 8,
      criticalNet: 'u_alu/adder_stage3_carry_out'
    },
    {
      id: 'P2',
      startPoint: 'mult_stage1_reg/Q',
      endPoint: 'mult_stage2_reg/D',
      clockDomain: 'clk_core (500MHz)',
      requiredTimeNs: clockPeriodNs * 0.95,
      arrivalTimeNs: Number((clockPeriodNs * 0.65 * (pvtCorner === 'SS_0.9V_125C' ? 1.15 : pvtCorner === 'FF_1.1V_-40C' ? 0.82 : 1.0)).toFixed(3)),
      slackNs: Number(((clockPeriodNs * 0.95) - (clockPeriodNs * 0.65 * (pvtCorner === 'SS_0.9V_125C' ? 1.15 : pvtCorner === 'FF_1.1V_-40C' ? 0.82 : 1.0))).toFixed(3)),
      type: 'setup',
      status: 'MET',
      logicLevels: 4,
      fanoutMax: 4,
      criticalNet: 'u_mult/booth_encoder_out[7]'
    },
    {
      id: 'P3',
      startPoint: 'fsm_state_reg[0]/Q',
      endPoint: 'next_state_reg[1]/D',
      clockDomain: 'clk_core (500MHz)',
      requiredTimeNs: clockPeriodNs * 0.90,
      arrivalTimeNs: Number((clockPeriodNs * 0.42 * (pvtCorner === 'SS_0.9V_125C' ? 1.12 : pvtCorner === 'FF_1.1V_-40C' ? 0.88 : 1.0)).toFixed(3)),
      slackNs: Number(((clockPeriodNs * 0.90) - (clockPeriodNs * 0.42 * (pvtCorner === 'SS_0.9V_125C' ? 1.12 : pvtCorner === 'FF_1.1V_-40C' ? 0.88 : 1.0))).toFixed(3)),
      type: 'setup',
      status: 'MET',
      logicLevels: 3,
      fanoutMax: 6,
      criticalNet: 'u_fsm/decoder_minterm_3'
    }
  ];

  const holdPaths: StaPathItem[] = [
    {
      id: 'H1',
      startPoint: 'shift_reg_0/Q',
      endPoint: 'shift_reg_1/D',
      clockDomain: 'clk_core (500MHz)',
      requiredTimeNs: 0.12,
      arrivalTimeNs: Number((0.28 * (pvtCorner === 'FF_1.1V_-40C' ? 0.75 : pvtCorner === 'SS_0.9V_125C' ? 1.25 : 1.0)).toFixed(3)),
      slackNs: Number(((0.28 * (pvtCorner === 'FF_1.1V_-40C' ? 0.75 : pvtCorner === 'SS_0.9V_125C' ? 1.25 : 1.0)) - 0.12).toFixed(3)),
      type: 'hold',
      status: 'MET',
      logicLevels: 1,
      fanoutMax: 2,
      criticalNet: 'u_shift/din_net'
    },
    {
      id: 'H2',
      startPoint: 'pipeline_stage1_reg/Q',
      endPoint: 'pipeline_stage2_reg/D',
      clockDomain: 'clk_core (500MHz)',
      requiredTimeNs: 0.15,
      arrivalTimeNs: Number((0.34 * (pvtCorner === 'FF_1.1V_-40C' ? 0.72 : pvtCorner === 'SS_0.9V_125C' ? 1.22 : 1.0)).toFixed(3)),
      slackNs: Number(((0.34 * (pvtCorner === 'FF_1.1V_-40C' ? 0.72 : pvtCorner === 'SS_0.9V_125C' ? 1.22 : 1.0)) - 0.15).toFixed(3)),
      type: 'hold',
      status: 'MET',
      logicLevels: 1,
      fanoutMax: 1,
      criticalNet: 'u_pipe/stage1_q'
    }
  ];

  const currentPaths = activePathTab === 'setup' ? setupPaths : holdPaths;
  const activePath = currentPaths.find(p => p.id === selectedPathId) || currentPaths[0];

  const worstSetupSlack = Math.min(...setupPaths.map(p => p.slackNs));
  const worstHoldSlack = Math.min(...holdPaths.map(p => p.slackNs));
  const maxFreqMhz = Math.round(1000 / (clockPeriodNs - (worstSetupSlack < 0 ? worstSetupSlack : 0)));

  return (
    <div className="h-full overflow-y-auto bg-[#111215] text-gray-200 p-6 space-y-6">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-[#181a20] via-[#1f232b] to-[#181a20] border border-emerald-500/20 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
            <Clock size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 tracking-wider">
                STAGE 6
              </span>
              <h1 className="text-xl font-bold text-white tracking-wide">
                Static Timing Analysis (STA) & Timing Sign-off
              </h1>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              Full-chip setup/hold slack calculation, clock skew breakdown & critical path timing closure
            </p>
          </div>
        </div>

        {/* Global Signoff Badge */}
        <div className="flex items-center gap-3">
          <div className={`px-4 py-2 rounded-xl flex items-center gap-2 border font-medium text-xs ${
            worstSetupSlack >= 0 && worstHoldSlack >= 0 
              ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400' 
              : 'bg-rose-500/10 border-rose-500/40 text-rose-400'
          }`}>
            {worstSetupSlack >= 0 && worstHoldSlack >= 0 ? <CheckCircle2 size={16} /> : <AlertTriangle size={16} />}
            <span>{worstSetupSlack >= 0 && worstHoldSlack >= 0 ? 'TIMING SIGN-OFF PASSED' : 'TIMING VIOLATION'}</span>
          </div>
        </div>
      </div>

      {/* Control Toolbar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* PVT Corner Selection */}
        <div className="p-4 rounded-xl bg-[#16181d] border border-white/10 space-y-2">
          <label className="text-xs text-gray-400 flex items-center gap-1.5 font-medium">
            <Sliders size={14} className="text-emerald-400" /> PVT Operating Corner
          </label>
          <select
            value={pvtCorner}
            onChange={(e) => setPvtCorner(e.target.value as any)}
            className="w-full bg-black/60 border border-white/15 text-xs text-gray-200 rounded-lg px-3 py-2 outline-none focus:border-emerald-500"
          >
            <option value="TT_1.0V_25C">Typical (TT / 1.00V / 25°C)</option>
            <option value="SS_0.9V_125C">Slow-Slow (SS / 0.90V / 125°C - Worst Setup)</option>
            <option value="FF_1.1V_-40C">Fast-Fast (FF / 1.10V / -40°C - Worst Hold)</option>
          </select>
        </div>

        {/* Target Clock Period Slider */}
        <div className="p-4 rounded-xl bg-[#16181d] border border-white/10 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-gray-400 font-medium">Target Clock Period ($T_{'{clk}'}$)</span>
            <span className="text-emerald-400 font-mono font-bold">{clockPeriodNs.toFixed(2)} ns ({(1000 / clockPeriodNs).toFixed(0)} MHz)</span>
          </div>
          <input
            type="range"
            min="1.0"
            max="5.0"
            step="0.1"
            value={clockPeriodNs}
            onChange={(e) => setClockPeriodNs(parseFloat(e.target.value))}
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        {/* Max Frequency Card */}
        <div className="p-4 rounded-xl bg-[#16181d] border border-white/10 flex items-center justify-between">
          <div>
            <div className="text-xs text-gray-400 font-medium">FMAX Achievable</div>
            <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">{maxFreqMhz} MHz</div>
          </div>
          <div className="p-3 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Zap size={22} />
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#16181d] border border-white/10">
          <div className="text-xs text-gray-400">Worst Setup Slack (WNS)</div>
          <div className={`text-xl font-bold font-mono mt-1 ${worstSetupSlack >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {worstSetupSlack >= 0 ? `+${worstSetupSlack}` : worstSetupSlack} ns
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#16181d] border border-white/10">
          <div className="text-xs text-gray-400">Worst Hold Slack (WHS)</div>
          <div className={`text-xl font-bold font-mono mt-1 ${worstHoldSlack >= 0 ? 'text-cyan-400' : 'text-rose-400'}`}>
            +{worstHoldSlack} ns
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#16181d] border border-white/10">
          <div className="text-xs text-gray-400 font-medium">Clock Skew Target</div>
          <div className="text-xl font-bold font-mono text-purple-400 mt-1">42.5 ps</div>
        </div>

        <div className="p-4 rounded-xl bg-[#16181d] border border-white/10">
          <div className="text-xs text-gray-400">Total Failing Endpoints</div>
          <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
            {worstSetupSlack < 0 ? '1 Path' : '0 Paths'}
          </div>
        </div>
      </div>

      {/* Main Analysis Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Timing Path Selector */}
        <div className="lg:col-span-5 p-5 rounded-2xl bg-[#16181d] border border-white/10 space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <Activity size={16} className="text-emerald-400" /> Timing Paths Inspector
            </h2>

            {/* Setup / Hold Toggle */}
            <div className="flex bg-black/60 p-1 rounded-lg border border-white/10 text-xs">
              <button
                onClick={() => { setActivePathTab('setup'); setSelectedPathId('P1'); }}
                className={`px-3 py-1 rounded-md transition ${activePathTab === 'setup' ? 'bg-emerald-600 text-white font-medium' : 'text-gray-400'}`}
              >
                Setup
              </button>
              <button
                onClick={() => { setActivePathTab('hold'); setSelectedPathId('H1'); }}
                className={`px-3 py-1 rounded-md transition ${activePathTab === 'hold' ? 'bg-cyan-600 text-white font-medium' : 'text-gray-400'}`}
              >
                Hold
              </button>
            </div>
          </div>

          <div className="space-y-2.5">
            {currentPaths.map((path) => (
              <div
                key={path.id}
                onClick={() => setSelectedPathId(path.id)}
                className={`p-3.5 rounded-xl border cursor-pointer transition ${
                  selectedPathId === path.id
                    ? 'bg-emerald-950/40 border-emerald-500/60 shadow-lg'
                    : 'bg-black/30 border-white/5 hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-white">{path.id}: {path.startPoint}</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    path.status === 'MET' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                  }`}>
                    {path.status}
                  </span>
                </div>
                <div className="text-[11px] text-gray-400 mt-1 flex items-center gap-1">
                  <span>→</span>
                  <span className="font-mono text-gray-300">{path.endPoint}</span>
                </div>
                <div className="flex justify-between items-center text-xs mt-2.5 pt-2 border-t border-white/5">
                  <span className="text-gray-400">Slack:</span>
                  <span className={`font-mono font-bold ${path.slackNs >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {path.slackNs >= 0 ? `+${path.slackNs}` : path.slackNs} ns
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Path Breakdown Details */}
        <div className="lg:col-span-7 p-5 rounded-2xl bg-[#16181d] border border-white/10 space-y-5">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div>
              <h2 className="text-sm font-semibold text-white">Path Timing Breakdown: {activePath.id}</h2>
              <p className="text-xs text-gray-400 mt-0.5">Critical Net: <code className="text-emerald-300 font-mono">{activePath.criticalNet}</code></p>
            </div>
            <div className={`px-3 py-1 rounded-lg text-xs font-mono font-bold ${
              activePath.slackNs >= 0 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
            }`}>
              Slack: {activePath.slackNs >= 0 ? `+${activePath.slackNs}` : activePath.slackNs} ns
            </div>
          </div>

          {/* Timeline Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b border-white/10 text-gray-400 bg-black/40">
                  <th className="p-2.5">Point</th>
                  <th className="p-2.5">Type</th>
                  <th className="p-2.5">Incr (ns)</th>
                  <th className="p-2.5">Path (ns)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono text-gray-300">
                <tr>
                  <td className="p-2.5 text-emerald-300">{activePath.startPoint}</td>
                  <td className="p-2.5 text-gray-400">clock edge</td>
                  <td className="p-2.5">0.000</td>
                  <td className="p-2.5">0.000</td>
                </tr>
                <tr>
                  <td className="p-2.5">u_clk_buf/Y</td>
                  <td className="p-2.5 text-gray-400">clock network delay</td>
                  <td className="p-2.5">0.140</td>
                  <td className="p-2.5">0.140</td>
                </tr>
                <tr>
                  <td className="p-2.5">reg_a_q_reg/Q</td>
                  <td className="p-2.5 text-gray-400">t_clk_to_q</td>
                  <td className="p-2.5">0.180</td>
                  <td className="p-2.5">0.320</td>
                </tr>
                <tr>
                  <td className="p-2.5 text-yellow-300">{activePath.criticalNet}</td>
                  <td className="p-2.5 text-gray-400">combinational gate delay</td>
                  <td className="p-2.5">{(activePath.arrivalTimeNs - 0.32).toFixed(3)}</td>
                  <td className="p-2.5 font-bold text-white">{activePath.arrivalTimeNs.toFixed(3)}</td>
                </tr>
                <tr className="bg-emerald-950/20 font-bold border-t border-emerald-500/30">
                  <td className="p-2.5 text-emerald-400">{activePath.endPoint}</td>
                  <td className="p-2.5 text-emerald-300">data arrival time</td>
                  <td className="p-2.5 text-emerald-400">-</td>
                  <td className="p-2.5 text-emerald-400">{activePath.arrivalTimeNs.toFixed(3)}</td>
                </tr>
                <tr className="bg-black/50">
                  <td className="p-2.5 text-purple-300">Required Time ($T_{'{req}'}$)</td>
                  <td className="p-2.5 text-gray-400">clock period - setup margin</td>
                  <td className="p-2.5 text-purple-300">-</td>
                  <td className="p-2.5 text-purple-300">{activePath.requiredTimeNs.toFixed(3)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Graphical Slack Bar */}
          <div className="p-4 rounded-xl bg-black/40 border border-white/5 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-gray-400">Path Delay Margin vs Target ({clockPeriodNs.toFixed(2)}ns)</span>
              <span className="font-mono font-bold text-emerald-400">
                {((activePath.arrivalTimeNs / clockPeriodNs) * 100).toFixed(1)}% of cycle used
              </span>
            </div>
            <div className="w-full h-3 bg-gray-800 rounded-full overflow-hidden flex">
              <div 
                className={`h-full ${activePath.slackNs >= 0 ? 'bg-emerald-500' : 'bg-rose-500'}`}
                style={{ width: `${Math.min(100, (activePath.arrivalTimeNs / clockPeriodNs) * 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
