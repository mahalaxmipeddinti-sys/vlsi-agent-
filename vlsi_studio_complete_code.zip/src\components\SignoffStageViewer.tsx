import React, { useState } from 'react';
import { 
  CheckCircle2, 
  ShieldCheck, 
  Download, 
  Layers, 
  AlertTriangle, 
  Box, 
  Cpu, 
  FileCheck, 
  Sparkles, 
  Activity,
  Flame,
  Check
} from 'lucide-react';
import { ThreeDCircuitViewer, ThreeDChipData } from './ThreeDCircuitViewer';

interface SignoffStageViewerProps {
  threeDData?: ThreeDChipData | null;
}

export function SignoffStageViewer({ threeDData }: SignoffStageViewerProps) {
  const [activeSignoffTab, setActiveSignoffTab] = useState<'checklist' | 'gdsii' | '3d'>('checklist');
  const [drcExported, setDrcExported] = useState(false);

  const signoffChecks = [
    {
      id: 'drc',
      name: 'Design Rule Check (DRC)',
      status: 'PASSED',
      violations: 0,
      details: 'Min Poly Width (20nm), Metal1 Pitch (36nm), Diffusion Enclosure passed with 0 errors.',
      icon: ShieldCheck,
      color: '#10B981'
    },
    {
      id: 'lvs',
      name: 'Layout Vs Schematic (LVS)',
      status: 'PASSED',
      violations: 0,
      details: 'Netlist topological match 100% matched between RTL synthesized netlist and routed layout.',
      icon: FileCheck,
      color: '#06B6D4'
    },
    {
      id: 'erc',
      name: 'Electrical Rule Check (ERC)',
      status: 'PASSED',
      violations: 0,
      details: 'No floating gates, well-tap density compliant, latch-up rule safe.',
      icon: Activity,
      color: '#8B5CF6'
    },
    {
      id: 'antenna',
      name: 'Antenna Rule Check',
      status: 'PASSED',
      violations: 0,
      details: 'Metal gate area ratios within safety limit; diode protection inserted on critical long nets.',
      icon: Flame,
      color: '#F59E0B'
    }
  ];

  const handleGenerateGdsStream = () => {
    setDrcExported(true);
    const content = `HEADER 600
BGNLIB 2026-09-22 19:45:00
LIBNAME VLSI_STUDIO_TOP_CELL
UNITS 0.001 1e-9
BGNSTR 2026-09-22 19:45:00
STRNAME CHIP_TOP
BOUNDARY LAYER 1 DATATYPE 0 XY 0 0 1000 0 1000 1000 0 1000 0 0 ENDEL
PATH LAYER 10 DATATYPE 0 PATHTYPE 0 WIDTH 40 XY 100 100 900 100 ENDEL
PATH LAYER 11 DATATYPE 0 PATHTYPE 0 WIDTH 40 XY 100 200 900 200 ENDEL
ENDSTR
ENDLIB`;

    const blob = new Blob([content], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'chip_final_signoff.gds';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setTimeout(() => setDrcExported(false), 3000);
  };

  return (
    <div className="h-full overflow-y-auto bg-[#111215] text-gray-200 p-6 space-y-6">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-[#181a20] via-[#1c2230] to-[#181a20] border border-blue-500/20 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400">
            <CheckCircle2 size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 tracking-wider">
                STAGE 7
              </span>
              <h1 className="text-xl font-bold text-white tracking-wide">
                Sign-off Stage (Physical Verification & GDSII Stream)
              </h1>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              DRC • LVS • ERC • Antenna checks & final GDSII stream-out for tapeout fabrication
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex bg-black/60 p-1 rounded-xl border border-white/10 text-xs">
          <button
            onClick={() => setActiveSignoffTab('checklist')}
            className={`px-4 py-2 rounded-lg font-medium transition ${activeSignoffTab === 'checklist' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'}`}
          >
            Verification Checklist
          </button>
          <button
            onClick={() => setActiveSignoffTab('gdsii')}
            className={`px-4 py-2 rounded-lg font-medium transition ${activeSignoffTab === 'gdsii' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'}`}
          >
            GDSII Export
          </button>
          <button
            onClick={() => setActiveSignoffTab('3d')}
            className={`px-4 py-2 rounded-lg font-medium transition ${activeSignoffTab === '3d' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'}`}
          >
            3D Stack Inspection
          </button>
        </div>
      </div>

      {activeSignoffTab === 'checklist' && (
        <div className="space-y-6">
          {/* Signoff Status Overview Card */}
          <div className="p-6 rounded-2xl bg-[#16181d] border border-white/10 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <ShieldCheck size={20} className="text-emerald-400" /> Tape-out Readiness Sign-off Matrix
                </h2>
                <p className="text-xs text-gray-400 mt-1">
                  All 4 physical verification engines report 0 violations. Design is certified clean for foundry submission.
                </p>
              </div>
              <div className="px-4 py-2 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center gap-2">
                <CheckCircle2 size={16} /> 100% CLEAN - READY FOR TAPEOUT
              </div>
            </div>

            {/* Checklist Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              {signoffChecks.map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.id} className="p-4 rounded-xl bg-black/40 border border-white/5 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                          <Icon size={18} />
                        </div>
                        <span className="text-sm font-semibold text-white">{item.name}</span>
                      </div>
                      <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/20 px-2.5 py-1 rounded">
                        0 VIOLATIONS
                      </span>
                    </div>
                    <p className="text-xs text-gray-400 leading-relaxed pt-1">
                      {item.details}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {activeSignoffTab === 'gdsii' && (
        <div className="p-6 rounded-2xl bg-[#16181d] border border-white/10 space-y-6">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Box size={20} className="text-blue-400" /> GDSII Stream File (.gds) Generator
              </h2>
              <p className="text-xs text-gray-400 mt-1">
                Binary stream data containing all mask layer polygons (FinFET, Poly, Contacts, Metal1-Metal6)
              </p>
            </div>
            <button
              onClick={handleGenerateGdsStream}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-xs shadow-lg flex items-center gap-2 transition"
            >
              {drcExported ? <Check size={16} /> : <Download size={16} />}
              <span>{drcExported ? 'GDSII Downloaded!' : 'Export GDSII Stream'}</span>
            </button>
          </div>

          <div className="bg-black/60 p-4 rounded-xl border border-white/10 font-mono text-xs text-emerald-400 leading-relaxed overflow-x-auto">
            <div className="text-gray-500">// GDSII Stream Header Dump</div>
            <div>HEADER 600</div>
            <div>BGNLIB 2026-09-22 19:45:00</div>
            <div>LIBNAME VLSI_STUDIO_TOP_CELL</div>
            <div>UNITS 0.001 1e-9</div>
            <div>BGNSTR 2026-09-22 19:45:00</div>
            <div>STRNAME CHIP_TOP</div>
            <div className="text-blue-300">  BOUNDARY LAYER 1 (Diffusion) XY 0 0 1000 0 1000 1000 0 1000</div>
            <div className="text-yellow-300">  PATH LAYER 10 (Metal1) WIDTH 40 XY 100 100 900 100</div>
            <div className="text-purple-300">  PATH LAYER 11 (Metal2) WIDTH 40 XY 100 200 900 200</div>
            <div>ENDSTR</div>
            <div>ENDLIB</div>
          </div>
        </div>
      )}

      {activeSignoffTab === '3d' && (
        <div className="h-[600px] rounded-2xl overflow-hidden border border-white/10 bg-black">
          <ThreeDCircuitViewer data={threeDData} />
        </div>
      )}
    </div>
  );
}
