import React, { useState } from 'react';
import { ChatInterface } from './components/chartinterface';
import { CodeEditor } from './components/CodeEditor';
import { LogicDiagramViewer } from './components/LogicDiagramViewer';
import { WaveformViewer } from './components/WaveformViewer';
import { TruthTableViewer } from './components/TruthTableViewer';
import { VerificationReport } from './components/VerificationReport';
import { LogicalVerificationWorkbench } from './components/LogicalVerificationWorkbench';
import { RtlVerificationWorkbench } from './components/RtlVerificationWorkbench';
import { SchematicViewer, SchematicData } from './components/SchematicViewer';
import { FloorplanViewer } from './components/FloorplanViewer';
import { PowerPlanViewer } from './components/PowerPlanViewer';
import { FloorplanConfig, PowerPlanConfig } from './types/physicalDesign';
import { createDefaultFloorplanConfig, createDefaultPowerPlan } from './utils/physicalDesignEngine';
import { CmosDesignViewer, CmosDesignData } from './components/CmosDesignViewer';
import { ThreeDCircuitViewer, ThreeDChipData } from './components/ThreeDCircuitViewer';
import { PinDiagramViewer, PinDiagramData } from './components/PinDiagramViewer';
import { StaAnalysisViewer } from './components/StaAnalysisViewer';
import { SignoffStageViewer } from './components/SignoffStageViewer';
import {
  Sparkles, X, ArrowRight, Zap, Code2, Activity, ShieldCheck,
  CheckCircle2, FileText, GitBranch, Box, Flame, LayoutGrid,
  Clock, Layers, Package, Monitor, History, ChevronLeft, Menu
} from 'lucide-react';
import {
  generateRtl, generateTestbench, verifyRtl, generateDiagram,
  designChip, generateWaveform, generateTruthTable, generateSchematicData,
  generateFloorplanData, generatePowerPlanData, generateCmosDesignData,
  generate3DChipData, generatePinDiagramData
} from './services/geminiService';

// ─── Tab types ───
type AppTab =
  | 'chat'
  | 'rtl' | 'testbench' | 'truthtable' | 'pin' | 'cmos'
  | 'schematic' | 'threed' | 'floorplan' | 'powerplan'
  | 'waveform' | 'diagram' | 'verification' | 'architecture'
  | 'sta' | 'signoff';

// ─── Flow items ───
interface FlowItem {
  num: number; title: string; sub: string;
  tab: AppTab; icon: React.ElementType; color: string;
}

const frontEndFlows: FlowItem[] = [
  { num: 1, title: 'Specification',        sub: 'Basic info • I/O • Functional behaviour',           tab: 'architecture', icon: FileText,     color: '#06B6D4' },
  { num: 2, title: 'Logical Diagram',      sub: 'Schematic diagram',                                tab: 'diagram',      icon: GitBranch,    color: '#8B5CF6' },
  { num: 3, title: 'Logical Verification', sub: 'Logical diagram • Truth tables • Wave forms • ...', tab: 'verification', icon: Activity,     color: '#10B981' },
  { num: 4, title: 'RTL Design',           sub: 'VHDL • Verilog • SystemVerilog',                   tab: 'rtl',          icon: Code2,        color: '#F59E0B' },
  { num: 5, title: 'RTL Verification',     sub: 'Test benches',                                     tab: 'testbench',    icon: ShieldCheck,  color: '#EF4444' },
  { num: 6, title: 'Logic Synthesis',      sub: 'CMOS logic ckt',                                   tab: 'cmos',         icon: Zap,          color: '#FBBF24' },
  { num: 7, title: 'DFT Verification',     sub: 'Test patterns',                                    tab: 'truthtable',   icon: CheckCircle2, color: '#34D399' },
];

const backEndFlows: FlowItem[] = [
  { num: 1, title: 'Floorplan',                  sub: 'Die area • Core aspect ratio • I/O pad rings',     tab: 'floorplan',  icon: Box,           color: '#06B6D4' },
  { num: 2, title: 'Power Plan',                 sub: 'Power rings • Straps • VDD/VSS PDN mesh',          tab: 'powerplan',  icon: Flame,         color: '#F59E0B' },
  { num: 3, title: 'Placement',                  sub: 'Standard cell placement • Legalization • Density', tab: 'pin',        icon: LayoutGrid,    color: '#10B981' },
  { num: 4, title: 'Clock Tree Synthesis (CTS)', sub: 'CTS H-Tree mesh • Skew & latency minimization',   tab: 'waveform',   icon: GitBranch,     color: '#06B6D4' },
  { num: 5, title: 'Routing',                    sub: 'Global & detailed routing • Metal layers M1–M6',  tab: 'schematic',  icon: Layers,        color: '#8B5CF6' },
  { num: 6, title: 'Static Timing Analysis (STA)', sub: 'Setup & hold slack • Critical path • Timing signoff', tab: 'sta',     icon: Clock,         color: '#10B981' },
  { num: 7, title: 'Sign-off Stage',             sub: 'DRC • LVS • ERC • Antenna • GDSII stream-out',    tab: 'signoff',    icon: CheckCircle2,  color: '#3B82F6' },
];

// ─── Sidebar Drawer ───
function SidebarDrawer({
  isOpen, onClose, activeTab, onSelectTab,
}: {
  isOpen: boolean;
  onClose: () => void;
  activeTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
}) {
  const handleClick = (tab: AppTab) => {
    onSelectTab(tab);
    onClose();
  };

  return (
    <>
      {isOpen && (
        <div
          onClick={onClose}
          style={{
            position: 'fixed', inset: 0,
            background: 'rgba(0,0,0,0.65)',
            backdropFilter: 'blur(2px)',
            zIndex: 40,
          }}
        />
      )}

      <div
        style={{
          position: 'fixed', top: 0, left: 0,
          height: '100%', width: 224,
          background: '#111215',
          borderRight: '1px solid rgba(255,255,255,0.08)',
          zIndex: 50,
          transform: isOpen ? 'translateX(0)' : 'translateX(-100%)',
          transition: 'transform 0.28s cubic-bezier(.22,1,.36,1)',
          display: 'flex', flexDirection: 'column',
        }}
      >
        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0.875rem 1rem',
          borderBottom: '1px solid rgba(255,255,255,0.07)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <div style={{
              width: 32, height: 32,
              background: 'linear-gradient(135deg,#064E3B,#065F46)',
              borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Sparkles size={16} color="#10B981" />
            </div>
            <div>
              <div style={{ fontWeight: 700, color: '#F8FAFC', fontSize: '0.8rem' }}>Front End &amp; Back End Flow</div>
              <div style={{ color: '#475569', fontSize: '0.62rem' }}>VLSI EDA ASIC &amp; Physical Design Pipeline</div>
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: 7, color: '#64748B', cursor: 'pointer', padding: 5,
              display: 'flex', alignItems: 'center',
            }}
          >
            <X size={15} />
          </button>
        </div>

        {/* Scrollable body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '0.5rem 0' }}>

          {/* ── Main Screen item ── */}
          <NavItem
            icon={<Monitor size={15} color="#10B981" />}
            label="Main Screen (Design Board & Assistant)"
            sub="Interactive Pipeline & Prompt Bar"
            isActive={activeTab === 'chat'}
            badge={null}
            accentColor="#10B981"
            onClick={() => handleClick('chat')}
          />

          {/* ── History item ── */}
          <NavItem
            icon={<History size={15} color="#F59E0B" />}
            label="Usage & Prompt History"
            sub="Past prompts, components & queries"
            isActive={false}
            badge="Log"
            accentColor="#F59E0B"
            onClick={() => handleClick('chat')}
          />

          {/* ── Divider ── */}
          <div style={{ height: 1, background: 'rgba(255,255,255,0.06)', margin: '0.5rem 0' }} />

          {/* ── Front End Part ── */}
          <SectionHeader label="FRONT END PART" />
          <div style={{
            margin: '0 0.75rem 0.5rem',
            border: '1px solid rgba(16,185,129,0.22)',
            borderRadius: 10, overflow: 'hidden',
            background: 'rgba(16,185,129,0.02)',
          }}>
            {frontEndFlows.map((flow, idx) => (
              <FlowRow
                key={idx}
                flow={flow}
                isActive={activeTab === flow.tab}
                isFirst={idx === 0}
                onClick={() => handleClick(flow.tab)}
              />
            ))}
          </div>

          {/* ── Back End Part ── */}
          <SectionHeader label="BACK END PART" />
          <div style={{
            margin: '0 0.75rem 0.75rem',
            border: '1px solid rgba(16,185,129,0.22)',
            borderRadius: 10, overflow: 'hidden',
            background: 'rgba(16,185,129,0.02)',
          }}>
            {backEndFlows.map((flow, idx) => (
              <FlowRow
                key={idx}
                flow={flow}
                isActive={activeTab === flow.tab}
                isFirst={idx === 0}
                onClick={() => handleClick(flow.tab)}
              />
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

function NavItem({ icon, label, sub, isActive, badge, accentColor, onClick }: {
  icon: React.ReactNode; label: string; sub: string;
  isActive: boolean; badge: string | null; accentColor: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        width: '100%', display: 'flex', alignItems: 'center', gap: '0.75rem',
        padding: '0.65rem 1rem',
        background: isActive ? `${accentColor}14` : 'transparent',
        border: 'none',
        borderLeft: isActive ? `2px solid ${accentColor}` : '2px solid transparent',
        cursor: 'pointer', textAlign: 'left', transition: 'background 0.15s',
      }}
      onMouseEnter={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)'; }}
      onMouseLeave={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
    >
      <div style={{ flexShrink: 0 }}>{icon}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          color: isActive ? '#F8FAFC' : '#CBD5E1', fontSize: '0.78rem',
          fontWeight: isActive ? 600 : 500,
          display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap',
        }}>
          <span style={{ flex: 1, minWidth: 0, lineHeight: 1.3 }}>{label}</span>
          {badge && (
            <span style={{
              fontSize: '0.62rem', fontWeight: 700,
              background: 'rgba(245,158,11,0.15)',
              border: '1px solid rgba(245,158,11,0.3)',
              color: '#F59E0B', padding: '1px 6px', borderRadius: 10, flexShrink: 0,
            }}>{badge}</span>
          )}
        </div>
        <div style={{ color: '#475569', fontSize: '0.68rem', marginTop: 1, lineHeight: 1.3 }}>{sub}</div>
      </div>
    </button>
  );
}

function SectionHeader({ label }: { label: string }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: '0.4rem',
      padding: '0.4rem 1rem 0.3rem',
    }}>
      <span style={{ color: '#10B981', fontFamily: 'monospace', fontSize: '0.95rem', lineHeight: 1 }}>{`{`}</span>
      <span style={{ color: '#10B981', fontSize: '0.65rem', fontWeight: 700, letterSpacing: '0.1em' }}>{label}</span>
    </div>
  );
}

function FlowRow({ flow, isActive, isFirst, onClick }: {
  flow: FlowItem; isActive: boolean; isFirst: boolean; onClick: () => void;
}) {
  const Icon = flow.icon;
  return (
    <button
      onClick={onClick}
      style={{
        width: '100%', display: 'flex', alignItems: 'center', gap: '0.7rem',
        padding: '0.6rem 0.875rem',
        background: isActive ? 'rgba(16,185,129,0.1)' : 'transparent',
        border: 'none',
        borderTop: isFirst ? 'none' : '1px solid rgba(255,255,255,0.04)',
        cursor: 'pointer', textAlign: 'left', transition: 'background 0.15s',
      }}
      onMouseEnter={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)'; }}
      onMouseLeave={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
    >
      <Icon size={14} color={flow.color} style={{ flexShrink: 0 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ color: isActive ? '#F8FAFC' : '#CBD5E1', fontSize: '0.78rem', fontWeight: isActive ? 600 : 400, marginBottom: 1 }}>
          {flow.num}. {flow.title}
        </div>
        <div style={{ color: '#475569', fontSize: '0.67rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {flow.sub}
        </div>
      </div>
      <ArrowRight size={12} color={isActive ? '#10B981' : '#334155'} style={{ flexShrink: 0 }} />
    </button>
  );
}

// ─── Design View Tab bar ───
const TAB_LABELS: Partial<Record<AppTab, string>> = {
  rtl: 'RTL Design', testbench: 'Testbench', truthtable: 'DFT Verification',
  pin: 'Placement', cmos: 'Logic Synthesis', schematic: 'Routing',
  threed: '3D Silicon Stack', floorplan: 'Floorplan', powerplan: 'Power Plan',
  waveform: 'CTS / Waveform', diagram: 'Logical Diagram', verification: 'Logical Verification',
  architecture: 'Specification',
};

// ─── Main App ───
export default function App() {
  const [activeTab, setActiveTab] = useState<AppTab>('chat');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [activeIcId, setActiveIcId] = useState<string | undefined>();

  // Multi-Language RTL states
  const [selectedRtlLang, setSelectedRtlLang] = useState<'verilog' | 'systemverilog' | 'vhdl'>('verilog');
  const [rtlVerilog, setRtlVerilog] = useState(`// 4-bit Arithmetic Logic Unit (Verilog)
module alu_4bit (
    input  wire [3:0] A,
    input  wire [3:0] B,
    input  wire [1:0] ALU_Sel,
    output reg  [3:0] ALU_Out,
    output reg        CarryOut
);
    always @(*) begin
        case (ALU_Sel)
            2'b00: {CarryOut, ALU_Out} = A + B;
            2'b01: {CarryOut, ALU_Out} = A - B;
            2'b10: begin ALU_Out = A & B; CarryOut = 0; end
            2'b11: begin ALU_Out = A | B; CarryOut = 0; end
            default: begin ALU_Out = 4'b0000; CarryOut = 0; end
        endcase
    end
endmodule`);

  const [rtlSystemVerilog, setRtlSystemVerilog] = useState(`// 4-bit Arithmetic Logic Unit (SystemVerilog)
module alu_4bit (
    input  logic [3:0] A,
    input  logic [3:0] B,
    input  logic [1:0] ALU_Sel,
    output logic [3:0] ALU_Out,
    output logic       CarryOut
);
    always_comb begin
        case (ALU_Sel)
            2'b00: {CarryOut, ALU_Out} = A + B;
            2'b01: {CarryOut, ALU_Out} = A - B;
            2'b10: begin ALU_Out = A & B; CarryOut = 1'b0; end
            2'b11: begin ALU_Out = A | B; CarryOut = 1'b0; end
            default: begin ALU_Out = 4'b0000; CarryOut = 1'b0; end
        endcase
    end
endmodule`);

  const [rtlVhdl, setRtlVhdl] = useState(`-- 4-Bit Arithmetic Logic Unit (ALU) - VHDL
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity alu_4bit is
    Port ( A        : in  STD_LOGIC_VECTOR (3 downto 0);
           B        : in  STD_LOGIC_VECTOR (3 downto 0);
           ALU_Sel  : in  STD_LOGIC_VECTOR (1 downto 0);
           ALU_Out  : out STD_LOGIC_VECTOR (3 downto 0);
           CarryOut : out STD_LOGIC);
end alu_4bit;

architecture Behavioral of alu_4bit is
    signal result : STD_LOGIC_VECTOR (4 downto 0);
begin
    process(A, B, ALU_Sel)
    begin
        case ALU_Sel is
            when "00" => result <= ('0' & A) + ('0' & B);
            when "01" => result <= ('0' & A) - ('0' & B);
            when "10" => result <= '0' & (A and B);
            when "11" => result <= '0' & (A or B);
            when others => result <= (others => '0');
        end case;
    end process;
    ALU_Out  <= result(3 downto 0);
    CarryOut <= result(4);
end Behavioral;`);

  // Active RTL code helper
  const activeRtlCode = selectedRtlLang === 'vhdl' ? rtlVhdl : selectedRtlLang === 'systemverilog' ? rtlSystemVerilog : rtlVerilog;
  const setRtlCode = (code: string) => {
    if (selectedRtlLang === 'vhdl') setRtlVhdl(code);
    else if (selectedRtlLang === 'systemverilog') setRtlSystemVerilog(code);
    else setRtlVerilog(code);
  };

  const [testbenchCode, setTestbenchCode] = useState('// Generate testbench from RTL');
  const [verificationReport, setVerificationReport] = useState('No report generated yet.');
  const [diagramData, setDiagramData] = useState<any>(null);
  const [waveformData, setWaveformData] = useState<any>(null);
  const [truthTableData, setTruthTableData] = useState<any>(null);
  const [architectureDoc, setArchitectureDoc] = useState('No architecture designed yet.');
  const [schematicData, setSchematicData] = useState<SchematicData | null>(null);
  const [floorplanData, setFloorplanData] = useState<FloorplanConfig | null>(null);
  const [powerPlanData, setPowerPlanData] = useState<PowerPlanConfig | null>(null);
  const [cmosData, setCmosData] = useState<CmosDesignData | null>(null);
  const [threeDData, setThreeDData] = useState<ThreeDChipData | null>(null);
  const [pinDiagramData, setPinDiagramData] = useState<PinDiagramData | null>(null);

  // Loading flags
  const [isGeneratingRtl, setIsGeneratingRtl] = useState(false);
  const [isGeneratingDiagram, setIsGeneratingDiagram] = useState(false);
  const [isGeneratingPin, setIsGeneratingPin] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);

  // ─── RTL generation ───
  const handleGenerateRtl = async (description: string) => {
    setIsGeneratingRtl(true);
    setActiveTab('rtl');
    try {
      const vCode = await generateRtl(description, 'verilog');
      const svCode = await generateRtl(description, 'systemverilog');
      const vhdlCode = await generateRtl(description, 'vhdl');

      if (vCode) setRtlVerilog(vCode);
      if (svCode) setRtlSystemVerilog(svCode);
      if (vhdlCode) setRtlVhdl(vhdlCode);

      const code = vCode || svCode || vhdlCode;
      if (!code) return;
      generateTestbench(code).then(tb => { if (tb) { setTestbenchCode(tb); generateWaveform(code, tb).then(wf => wf && setWaveformData(wf)); } });
      generateDiagram(code).then(d => d && setDiagramData(d));
      generateTruthTable(code).then(tt => tt && setTruthTableData(tt));
      verifyRtl(code).then(r => r && setVerificationReport(r));
      designChip(description || code).then(doc => doc && setArchitectureDoc(doc));
      generateSchematicData(code).then(s => s && setSchematicData(s));
      generateFloorplanData(code).then(fp => fp && setFloorplanData(fp));
      generatePowerPlanData(code).then(pp => pp && setPowerPlanData(pp));
      generateCmosDesignData(code).then(cm => cm && setCmosData(cm));
      generate3DChipData(code).then(td => td && setThreeDData(td));
      generatePinDiagramData(code).then(pd => pd && setPinDiagramData(pd));
    } catch (e) { console.error(e); }
    finally { setIsGeneratingRtl(false); }
  };

  // ─── Tab navigation ───
  const handleNavigateToTab = (tabId: string) => {
    setActiveTab(tabId as AppTab);
    if (tabId === 'chat') return;
    if (!activeRtlCode || activeRtlCode.startsWith('//')) return;
    if (tabId === 'diagram')     { setIsGeneratingDiagram(true); generateDiagram(activeRtlCode).then(d => { d && setDiagramData(d); setIsGeneratingDiagram(false); }); }
    if (tabId === 'pin')         { setIsGeneratingPin(true); generatePinDiagramData(activeRtlCode).then(d => { d && setPinDiagramData(d); setIsGeneratingPin(false); }); }
    if (tabId === 'verification'){ setIsVerifying(true); verifyRtl(activeRtlCode).then(r => { r && setVerificationReport(r); setIsVerifying(false); }); }
    if (tabId === 'cmos')        generateCmosDesignData(activeRtlCode).then(cm => cm && setCmosData(cm));
    if (tabId === 'schematic')   generateSchematicData(activeRtlCode).then(s => s && setSchematicData(s));
    if (tabId === 'floorplan')   generateFloorplanData(activeRtlCode).then(fp => fp && setFloorplanData(fp));
    if (tabId === 'powerplan')   generatePowerPlanData(activeRtlCode).then(pp => pp && setPowerPlanData(pp));
    if (tabId === 'threed')      generate3DChipData(activeRtlCode).then(td => td && setThreeDData(td));
  };

  const isDesignTab = activeTab !== 'chat';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: '#0B0F19', color: '#F8FAFC', fontFamily: 'Inter, sans-serif', overflow: 'hidden' }}>

      {/* ── Slides & Tools Drawer ── */}
      <SidebarDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        activeTab={activeTab}
        onSelectTab={handleNavigateToTab as any}
      />

      {/* ── CHAT SCREEN (Main Screen) ── */}
      {activeTab === 'chat' && (
        <ChatInterface
          onToggleSidebar={() => setIsDrawerOpen(true)}
          onNavigateToTab={handleNavigateToTab}
          onOpenStudio={() => setActiveTab('rtl')}
          onLoadRtlCode={(code) => { setRtlCode(code); setActiveTab('rtl'); }}
          currentRtlCode={activeRtlCode.startsWith('//') ? undefined : activeRtlCode}
          activeIcId={activeIcId}
          onSelectComponent={setActiveIcId}
        />
      )}

      {/* ── DESIGN VIEW ── */}
      {isDesignTab && (
        <div style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>

          {/* Design tab bar */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: '0.5rem',
            padding: '0 1rem', height: 48,
            background: '#0D1117',
            borderBottom: '1px solid rgba(255,255,255,0.07)',
            flexShrink: 0, overflowX: 'auto',
          }}>
            {/* Slides & Tools Drawer Button */}
            <button
              onClick={() => setIsDrawerOpen(true)}
              style={{
                display: 'flex', alignItems: 'center', gap: '0.4rem',
                padding: '0.35rem 0.75rem', borderRadius: 8,
                background: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.15)',
                color: '#F8FAFC', fontSize: '0.76rem', fontWeight: 500, cursor: 'pointer',
                flexShrink: 0, fontFamily: 'Inter, sans-serif',
              }}
              title="Open Navigation Menu (Slides & Tools)"
            >
              <Menu size={16} color="#10B981" />
              <span>Slides &amp; Tools</span>
            </button>

            <div style={{ width: 1, height: 18, background: 'rgba(255,255,255,0.08)' }} />

            {/* Flow tabs */}
            {[...frontEndFlows, ...backEndFlows].map((flow) => {
              const isActive = activeTab === flow.tab;
              if (!isActive) return null;
              return (
                <div key={flow.tab} style={{
                  display: 'flex', alignItems: 'center', gap: '0.4rem',
                  padding: '0.3rem 0.8rem', borderRadius: 7,
                  background: `${flow.color}18`,
                  border: `1px solid ${flow.color}35`,
                  color: flow.color, fontSize: '0.77rem', fontWeight: 600,
                }}>
                  <flow.icon size={13} />
                  <span>{flow.title}</span>
                </div>
              );
            })}


            {isGeneratingRtl && (
              <span style={{
                marginLeft: 'auto', fontSize: '0.72rem', color: '#10B981',
                background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.25)',
                borderRadius: 20, padding: '2px 10px', flexShrink: 0,
              }}>
                ⟳ Synthesizing...
              </span>
            )}
          </div>

          {/* Viewer */}
          <div style={{ flex: 1, overflow: 'hidden', background: '#0B0F19' }}>
            {activeTab === 'rtl'          && (
              <CodeEditor 
                code={activeRtlCode} 
                onChange={setRtlCode} 
                language={selectedRtlLang}
                selectedLanguage={selectedRtlLang}
                onLanguageChange={setSelectedRtlLang}
                onGenerateRtl={handleGenerateRtl}
                isGenerating={isGeneratingRtl}
              />
            )}
            {activeTab === 'testbench'    && <RtlVerificationWorkbench rtlCode={activeRtlCode} onNavigateToTab={handleNavigateToTab} />}
            {activeTab === 'truthtable'   && <TruthTableViewer data={truthTableData} />}
            {activeTab === 'pin'          && <PinDiagramViewer data={pinDiagramData} onGenerate={() => { setIsGeneratingPin(true); generatePinDiagramData(activeRtlCode).then(d => { d && setPinDiagramData(d); setIsGeneratingPin(false); }); }} isGenerating={isGeneratingPin} />}
            {activeTab === 'diagram'      && <LogicDiagramViewer data={diagramData} onGenerate={() => { setIsGeneratingDiagram(true); generateDiagram(activeRtlCode).then(d => { d && setDiagramData(d); setIsGeneratingDiagram(false); }); }} isGenerating={isGeneratingDiagram} />}
            {activeTab === 'waveform'     && <WaveformViewer data={waveformData} />}
            {activeTab === 'schematic'    && <SchematicViewer data={schematicData} />}
            {activeTab === 'cmos'         && <CmosDesignViewer data={cmosData} />}
            {activeTab === 'floorplan'    && <FloorplanViewer config={floorplanData ?? createDefaultFloorplanConfig()} onChangeConfig={setFloorplanData} onResetToRtl={() => { if (activeRtlCode && !activeRtlCode.startsWith('//')) generateFloorplanData(activeRtlCode).then(fp => fp && setFloorplanData(fp)); }} />}
            {activeTab === 'powerplan'    && <PowerPlanViewer floorplan={floorplanData ?? createDefaultFloorplanConfig()} powerPlan={powerPlanData ?? createDefaultPowerPlan()} onChangePowerPlan={setPowerPlanData} />}
            {activeTab === 'threed'       && <ThreeDCircuitViewer data={threeDData} />}
            {activeTab === 'verification' && <LogicalVerificationWorkbench activeIcId={activeIcId} onNavigateToTab={handleNavigateToTab} onSelectCircuit={setActiveIcId} />}
            {activeTab === 'architecture' && <VerificationReport report={architectureDoc} />}
            {activeTab === 'sta'          && <StaAnalysisViewer />}
            {activeTab === 'signoff'      && <SignoffStageViewer threeDData={threeDData} />}
          </div>
        </div>
      )}
    </div>
  );
}
