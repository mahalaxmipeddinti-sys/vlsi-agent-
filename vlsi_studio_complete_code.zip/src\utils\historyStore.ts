// Simple localStorage-based history store for tracking prompts and component queries

export interface HistoryItem {
  id: string;
  query: string;
  componentName: string;
  componentType: string;
  icId: string;
  sourceStage: string;
  timestamp: number;
}

const HISTORY_KEY = 'vlsi_usage_history';
const MAX_ITEMS = 100;

export function saveHistoryItem(item: Omit<HistoryItem, 'id' | 'timestamp'>): void {
  try {
    const existing = getHistoryItems();
    const newItem: HistoryItem = {
      ...item,
      id: `hist-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: Date.now(),
    };
    const updated = [newItem, ...existing].slice(0, MAX_ITEMS);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to save history item:', e);
  }
}

export function getHistoryItems(): HistoryItem[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as HistoryItem[];
  } catch {
    return [];
  }
}

export function clearHistory(): void {
  try {
    localStorage.removeItem(HISTORY_KEY);
  } catch (e) {
    console.error(e);
  }
}

export function groupHistoryByDate(items: HistoryItem[]): { label: string; items: HistoryItem[] }[] {
  const now = Date.now();
  const DAY = 86400000;
  const groups: Record<string, HistoryItem[]> = {};

  items.forEach((item) => {
    const diff = now - item.timestamp;
    let label = 'Older';
    if (diff < DAY)      label = 'Today';
    else if (diff < 2 * DAY) label = 'Yesterday';
    else if (diff < 7 * DAY) label = 'This Week';
    else if (diff < 30 * DAY) label = 'This Month';
    if (!groups[label]) groups[label] = [];
    groups[label].push(item);
  });

  const order = ['Today', 'Yesterday', 'This Week', 'This Month', 'Older'];
  return order.filter((l) => groups[l]).map((l) => ({ label: l, items: groups[l] }));
}
