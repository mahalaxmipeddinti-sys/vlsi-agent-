import React, { useState, useMemo, useEffect } from 'react';
import { 
  Play, 
  RotateCcw, 
  Activity, 
  Table, 
  Cpu, 
  Sliders, 
  CheckCircle2, 
  ArrowRight,
  Maximize2,
  Sparkles
} from 'lucide-react';

export interface CircuitModel {
  id: string;
  name: string;
  type: string;
  signals: Array<{ name: string; label: string; desc: string; defaultValue: number }>;
  outputs: Array<{ name: string; label: string; desc: string }>;
  evaluate: (inputs: Record<string, number>, prevOutput?: Record<string, number>) => Record<string, number>;
  truthTableRows: Array<{ inputs: Record<string, number>; outputs: Record<string, number>; mode?: string }>;
}

export const CIRCUITS: Record<string, CircuitModel> = {
  '7476': {
    id: '7476',
    name: 'SN7476 Dual J-K Flip-Flop',
    type: 'Sequential Logic (Negative-Edge Storage Element with Preset & Clear)',
    signals: [
      { name: 'CLK', label: 'Clock (CLK)', desc: 'Negative Edge Trigger', defaultValue: 1 },
      { name: 'J', label: 'J Input', desc: 'Synchronous Data J', defaultValue: 1 },
      { name: 'K', label: 'K Input', desc: 'Synchronous Data K', defaultValue: 0 },
      { name: 'PRE_n', label: 'Preset (PRE_n)', desc: 'Active-Low Async Set', defaultValue: 1 },
      { name: 'CLR_n', label: 'Clear (CLR_n)', desc: 'Active-Low Async Reset', defaultValue: 1 },
    ],
    outputs: [
      { name: 'Q', label: 'True Output (Q)', desc: 'Current Stored State' },
      { name: 'Q_bar', label: 'Inverted Output (Q_bar)', desc: 'Complementary State' }
    ],
    evaluate: (inputs, prev = { Q: 0, Q_bar: 1 }) => {
      const pre_n = inputs.PRE_n ?? 1;
      const clr_n = inputs.CLR_n ?? 1;
      const j = inputs.J ?? 0;
      const k = inputs.K ?? 0;

      if (pre_n === 0 && clr_n === 0) {
        return { Q: 1, Q_bar: 1 }; // Non-stable
      }
      if (pre_n === 0) {
        return { Q: 1, Q_bar: 0 }; // Async Preset
      }
      if (clr_n === 0) {
        return { Q: 0, Q_bar: 1 }; // Async Clear
      }
      // Normal synchronous JK operation
      if (j === 0 && k === 0) {
        return { Q: prev.Q ?? 0, Q_bar: prev.Q_bar ?? 1 }; // Hold
      }
      if (j === 0 && k === 1) {
        return { Q: 0, Q_bar: 1 }; // Reset
      }
      if (j === 1 && k === 0) {
        return { Q: 1, Q_bar: 0 }; // Set
      }
      // Toggle
      const nextQ = prev.Q === 1 ? 0 : 1;
      return { Q: nextQ, Q_bar: nextQ === 1 ? 0 : 1 };
    },
    truthTableRows: [
      { inputs: { PRE_n: 0, CLR_n: 1, J: 0, K: 0, CLK: 0 }, outputs: { Q: 1, Q_bar: 0 }, mode: 'Async Preset' },
      { inputs: { PRE_n: 1, CLR_n: 0, J: 0, K: 0, CLK: 0 }, outputs: { Q: 0, Q_bar: 1 }, mode: 'Async Clear' },
      { inputs: { PRE_n: 0, CLR_n: 0, J: 0, K: 0, CLK: 0 }, outputs: { Q: 1, Q_bar: 1 }, mode: 'Invalid State' },
      { inputs: { PRE_n: 1, CLR_n: 1, J: 0, K: 0, CLK: 1 }, outputs: { Q: 0, Q_bar: 1 }, mode: 'Hold / Memory' },
      { inputs: { PRE_n: 1, CLR_n: 1, J: 0, K: 1, CLK: 1 }, outputs: { Q: 0, Q_bar: 1 }, mode: 'Reset (0)' },
      { inputs: { PRE_n: 1, CLR_n: 1, J: 1, K: 0, CLK: 1 }, outputs: { Q: 1, Q_bar: 0 }, mode: 'Set (1)' },
      { inputs: { PRE_n: 1, CLR_n: 1, J: 1, K: 1, CLK: 1 }, outputs: { Q: 1, Q_bar: 0 }, mode: 'Toggle' }
    ]
  },
  '7400': {
    id: '7400',
    name: 'SN7400 Quad 2-Input NAND Gate',
    type: 'Universal Combinational Logic (NAND Gate)',
    signals: [
      { name: 'A', label: 'Input A', desc: 'Gate Input 1', defaultValue: 0 },
      { name: 'B', label: 'Input B', desc: 'Gate Input 2', defaultValue: 0 },
    ],
    outputs: [
      { name: 'Y', label: 'Output Y', desc: 'NAND Output (A · B)\'' }
    ],
    evaluate: (inputs) => {
      const a = inputs.A ?? 0;
      const b = inputs.B ?? 0;
      const y = (a === 1 && b === 1) ? 0 : 1;
      return { Y: y };
    },
    truthTableRows: [
      { inputs: { A: 0, B: 0 }, outputs: { Y: 1 }, mode: 'Output High' },
      { inputs: { A: 0, B: 1 }, outputs: { Y: 1 }, mode: 'Output High' },
      { inputs: { A: 1, B: 0 }, outputs: { Y: 1 }, mode: 'Output High' },
      { inputs: { A: 1, B: 1 }, outputs: { Y: 0 }, mode: 'Output Low' }
    ]
  },
  '7402': {
    id: '7402',
    name: 'SN7402 Quad 2-Input NOR Gate',
    type: 'Universal Combinational Logic (NOR Gate)',
    signals: [
      { name: 'A', label: 'Input A', desc: 'Gate Input 1', defaultValue: 0 },
      { name: 'B', label: 'Input B', desc: 'Gate Input 2', defaultValue: 0 },
    ],
    outputs: [
      { name: 'Y', label: 'Output Y', desc: 'NOR Output (A + B)\'' }
    ],
    evaluate: (inputs) => {
      const a = inputs.A ?? 0;
      const b = inputs.B ?? 0;
      const y = (a === 0 && b === 0) ? 1 : 0;
      return { Y: y };
    },
    truthTableRows: [
      { inputs: { A: 0, B: 0 }, outputs: { Y: 1 }, mode: 'Output High' },
      { inputs: { A: 0, B: 1 }, outputs: { Y: 0 }, mode: 'Output Low' },
      { inputs: { A: 1, B: 0 }, outputs: { Y: 0 }, mode: 'Output Low' },
      { inputs: { A: 1, B: 1 }, outputs: { Y: 0 }, mode: 'Output Low' }
    ]
  },
  '7404': {
    id: '7404',
    name: 'SN7404 Hex Inverter (NOT Gate)',
    type: 'Basic Combinational Logic (Hex Inverter)',
    signals: [
      { name: 'A', label: 'Input A', desc: 'Logic Input', defaultValue: 0 }
    ],
    outputs: [
      { name: 'Y', label: 'Output Y', desc: 'Inverted Output A\'' }
    ],
    evaluate: (inputs) => {
      const a = inputs.A ?? 0;
      return { Y: a === 1 ? 0 : 1 };
    },
    truthTableRows: [
      { inputs: { A: 0 }, outputs: { Y: 1 }, mode: 'Inverted High' },
      { inputs: { A: 1 }, outputs: { Y: 0 }, mode: 'Inverted Low' }
    ]
  },
  '7408': {
    id: '7408',
    name: 'SN7408 Quad 2-Input AND Gate',
    type: 'Basic Combinational Logic (AND Gate)',
    signals: [
      { name: 'A', label: 'Input A', desc: 'Gate Input 1', defaultValue: 1 },
      { name: 'B', label: 'Input B', desc: 'Gate Input 2', defaultValue: 0 }
    ],
    outputs: [
      { name: 'Y', label: 'Output Y', desc: 'Conjunction A · B' }
    ],
    evaluate: (inputs) => {
      const a = inputs.A ?? 0;
      const b = inputs.B ?? 0;
      return { Y: (a === 1 && b === 1) ? 1 : 0 };
    },
    truthTableRows: [
      { inputs: { A: 0, B: 0 }, outputs: { Y: 0 }, mode: 'Output Low' },
      { inputs: { A: 0, B: 1 }, outputs: { Y: 0 }, mode: 'Output Low' },
      { inputs: { A: 1, B: 0 }, outputs: { Y: 0 }, mode: 'Output Low' },
      { inputs: { A: 1, B: 1 }, outputs: { Y: 1 }, mode: 'Output High' }
    ]
  },
  '7432': {
    id: '7432',
    name: 'SN7432 Quad 2-Input OR Gate',
    type: 'Basic Combinational Logic (OR Gate)',
    signals: [
      { name: 'A', label: 'Input A', desc: 'Gate Input 1', defaultValue: 1 },
      { name: 'B', label: 'Input B', desc: 'Gate Input 2', defaultValue: 0 }
    ],
    outputs: [
      { name: 'Y', label: 'Output Y', desc: 'Disjunction A + B' }
    ],
    evaluate: (inputs) => {
      const a = inputs.A ?? 0;
      const b = inputs.B ?? 0;
      return { Y: (a === 1 || b === 1) ? 1 : 0 };
    },
    truthTableRows: [
      { inputs: { A: 0, B: 0 }, outputs: { Y: 0 }, mode: 'Output Low' },
      { inputs: { A: 0, B: 1 }, outputs: { Y: 1 }, mode: 'Output High' },
      { inputs: { A: 1, B: 0 }, outputs: { Y: 1 }, mode: 'Output High' },
      { inputs: { A: 1, B: 1 }, outputs: { Y: 1 }, mode: 'Output High' }
    ]
  },
  '7486': {
    id: '7486',
    name: 'SN7486 Quad 2-Input XOR Gate',
    type: 'Arithmetic / Parity Logic (Exclusive-OR)',
    signals: [
      { name: 'A', label: 'Input A', desc: 'Operand A', defaultValue: 1 },
      { name: 'B', label: 'Input B', desc: 'Operand B', defaultValue: 0 }
    ],
    outputs: [
      { name: 'Y', label: 'Output Y', desc: 'XOR Sum (A ⊕ B)' }
    ],
    evaluate: (inputs) => {
      const a = inputs.A ?? 0;
      const b = inputs.B ?? 0;
      return { Y: (a ^ b) === 1 ? 1 : 0 };
    },
    truthTableRows: [
      { inputs: { A: 0, B: 0 }, outputs: { Y: 0 }, mode: 'Even Parity' },
      { inputs: { A: 0, B: 1 }, outputs: { Y: 1 }, mode: 'Odd Parity' },
      { inputs: { A: 1, B: 0 }, outputs: { Y: 1 }, mode: 'Odd Parity' },
      { inputs: { A: 1, B: 1 }, outputs: { Y: 0 }, mode: 'Even Parity' }
    ]
  },
  '7483': {
    id: '7483',
    name: 'SN7483 4-Bit Binary Full Adder',
    type: 'Arithmetic Logic Unit (Parallel Full Adder)',
    signals: [
      { name: 'A', label: 'Operand A', desc: 'Bit A', defaultValue: 1 },
      { name: 'B', label: 'Operand B', desc: 'Bit B', defaultValue: 0 },
      { name: 'Cin', label: 'Carry In (Cin)', desc: 'Carry In Bit', defaultValue: 1 },
      { name: 'EN', label: 'Enable (EN)', desc: 'Logic Gating', defaultValue: 1 }
    ],
    outputs: [
      { name: 'S', label: 'Sum (S)', desc: 'A ⊕ B ⊕ Cin' },
      { name: 'Cout', label: 'Carry Out (Cout)', desc: 'Carry Propagation' }
    ],
    evaluate: (inputs) => {
      const a = inputs.A ?? 0;
      const b = inputs.B ?? 0;
      const cin = inputs.Cin ?? 0;
      const en = inputs.EN ?? 1;
      if (!en) return { S: 0, Cout: 0 };
      const p = a ^ b;
      const g = a & b;
      const s = p ^ cin;
      const cout = g | (p & cin);
      return { S: s, Cout: cout };
    },
    truthTableRows: [
      { inputs: { A: 0, B: 0, Cin: 0 }, outputs: { S: 0, Cout: 0 }, mode: 'Sum 0, Carry 0' },
      { inputs: { A: 0, B: 0, Cin: 1 }, outputs: { S: 1, Cout: 0 }, mode: 'Sum 1, Carry 0' },
      { inputs: { A: 0, B: 1, Cin: 0 }, outputs: { S: 1, Cout: 0 }, mode: 'Sum 1, Carry 0' },
      { inputs: { A: 0, B: 1, Cin: 1 }, outputs: { S: 0, Cout: 1 }, mode: 'Sum 0, Carry 1' },
      { inputs: { A: 1, B: 0, Cin: 0 }, outputs: { S: 1, Cout: 0 }, mode: 'Sum 1, Carry 0' },
      { inputs: { A: 1, B: 0, Cin: 1 }, outputs: { S: 0, Cout: 1 }, mode: 'Sum 0, Carry 1' },
      { inputs: { A: 1, B: 1, Cin: 0 }, outputs: { S: 0, Cout: 1 }, mode: 'Sum 0, Carry 1' },
      { inputs: { A: 1, B: 1, Cin: 1 }, outputs: { S: 1, Cout: 1 }, mode: 'Sum 1, Carry 1' }
    ]
  }
};

interface LogicalVerificationWorkbenchProps {
  activeIcId?: string;
  circuitName?: string;
  onNavigateToTab?: (tabId: string) => void;
  onSelectCircuit?: (id: string) => void;
}

export function LogicalVerificationWorkbench({
  activeIcId = '7476',
  onNavigateToTab,
  onSelectCircuit
}: LogicalVerificationWorkbenchProps) {
  // Determine normalized active circuit key
  const normalizedKey = useMemo(() => {
    const raw = (activeIcId || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    if (raw.includes('7476') || raw.includes('jk')) return '7476';
    if (raw.includes('7400') || raw.includes('nand')) return '7400';
    if (raw.includes('7402') || raw.includes('nor')) return '7402';
    if (raw.includes('7404') || raw.includes('inv')) return '7404';
    if (raw.includes('7408') || raw.includes('and')) return '7408';
    if (raw.includes('7432') || raw.includes('or')) return '7432';
    if (raw.includes('7486') || raw.includes('xor')) return '7486';
    if (raw.includes('7483') || raw.includes('adder') || raw.includes('alu')) return '7483';
    return CIRCUITS[activeIcId] ? activeIcId : '7476';
  }, [activeIcId]);

  const [selectedCircuitId, setSelectedCircuitId] = useState<string>(normalizedKey);

  useEffect(() => {
    setSelectedCircuitId(normalizedKey);
  }, [normalizedKey]);

  const circuit = CIRCUITS[selectedCircuitId] || CIRCUITS['7476'];

  // Changeable inputs state
  const [inputs, setInputs] = useState<Record<string, number>>(() => {
    const init: Record<string, number> = {};
    circuit.signals.forEach(s => {
      init[s.name] = s.defaultValue;
    });
    return init;
  });

  // Re-initialize inputs when circuit changes
  useEffect(() => {
    const init: Record<string, number> = {};
    circuit.signals.forEach(s => {
      init[s.name] = s.defaultValue;
    });
    setInputs(init);
    setHistory([]);
  }, [selectedCircuitId]);

  const [outputs, setOutputs] = useState<Record<string, number>>(() => {
    return circuit.evaluate(inputs);
  });

  const [history, setHistory] = useState<Array<{ inputs: Record<string, number>; outputs: Record<string, number>; time: number }>>([]);

  // Compute logic outputs from inputs
  useEffect(() => {
    const newOut = circuit.evaluate(inputs, outputs);
    setOutputs(newOut);
    setHistory(prev => [
      ...prev.slice(-7),
      { inputs: { ...inputs }, outputs: newOut, time: (prev[prev.length - 1]?.time ?? 0) + 1 }
    ]);
  }, [inputs, selectedCircuitId]);

  // Handle toggling an input
  const toggleInput = (name: string) => {
    setInputs(prev => ({
      ...prev,
      [name]: prev[name] === 1 ? 0 : 1
    }));
  };

  const resetInputs = () => {
    const init: Record<string, number> = {};
    circuit.signals.forEach(s => {
      init[s.name] = s.defaultValue;
    });
    setInputs(init);
  };

  const handleCircuitTabChange = (id: string) => {
    setSelectedCircuitId(id);
    onSelectCircuit?.(id);
  };

  return (
    <div className="w-full h-full bg-[#111215] text-gray-200 overflow-y-auto p-4 sm:p-6 space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 p-4 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-[#1a1c21] to-[#141519] border border-emerald-500/25 shadow-lg">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <Activity size={20} />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                STAGE 3
              </span>
              <h2 className="text-base font-bold text-white tracking-tight">
                Logical Verification Workbench
              </h2>
            </div>
            <p className="text-xs text-gray-400 mt-0.5">
              Live verification suite: <strong className="text-emerald-300">Changeable Inputs</strong>, <strong className="text-blue-300">Gate Diagram</strong>, <strong className="text-amber-300">Truth Tables</strong>, and <strong className="text-purple-300">Real-time Waveforms</strong>.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={resetInputs}
            className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/10 text-xs flex items-center space-x-1.5 transition-colors"
            title="Reset Inputs"
          >
            <RotateCcw size={13} />
            <span>Reset Inputs</span>
          </button>
          {onNavigateToTab && (
            <button
              onClick={() => onNavigateToTab('waveform')}
              className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-semibold flex items-center space-x-1.5 transition-colors"
            >
              <Maximize2 size={13} />
              <span>Full Waveform Studio</span>
            </button>
          )}
        </div>
      </div>

      {/* Component Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-white/10">
        <span className="text-xs font-semibold text-gray-400 shrink-0 mr-1 flex items-center gap-1">
          <Cpu size={14} className="text-emerald-400" />
          Active Circuit:
        </span>
        {Object.values(CIRCUITS).map(c => {
          const isSelected = selectedCircuitId === c.id;
          return (
            <button
              key={c.id}
              onClick={() => handleCircuitTabChange(c.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium shrink-0 transition-all border ${
                isSelected
                  ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 shadow-md font-semibold'
                  : 'bg-white/5 border-white/5 text-gray-400 hover:text-gray-200 hover:bg-white/10'
              }`}
            >
              {c.name}
            </button>
          );
        })}
      </div>

      {/* The 4-in-1 Verification Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Module 1: Changeable Inputs (Col 1-4) */}
        <div className="lg:col-span-4 space-y-5">
          <div className="p-4 rounded-2xl bg-[#17181c] border border-white/10 shadow-md">
            <div className="flex items-center justify-between mb-3 border-b border-white/5 pb-2">
              <div className="flex items-center space-x-2">
                <Sliders size={16} className="text-emerald-400" />
                <h3 className="text-xs font-bold text-gray-100 uppercase tracking-wider">
                  Changeable Inputs
                </h3>
              </div>
              <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                LIVE TOGGLES
              </span>
            </div>

            <p className="text-[11px] text-gray-400 mb-4">
              Toggle any input switch to change its logic state (0 or 1). The schematic, truth table, and waveform react instantaneously.
            </p>

            <div className="space-y-2.5">
              {circuit.signals.map((sig) => {
                const val = inputs[sig.name] ?? 0;
                const isHigh = val === 1;
                return (
                  <div
                    key={sig.name}
                    onClick={() => toggleInput(sig.name)}
                    className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all select-none ${
                      isHigh
                        ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-200 shadow-sm'
                        : 'bg-black/30 border-white/10 hover:border-white/20 text-gray-300'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                        isHigh ? 'bg-emerald-500 text-black shadow-md' : 'bg-white/10 text-gray-400'
                      }`}>
                        {sig.name}
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-white">{sig.label}</div>
                        <div className="text-[10px] text-gray-400">{sig.desc}</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <span className={`font-mono text-xs font-bold px-2 py-0.5 rounded ${
                        isHigh ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-gray-800 text-gray-400'
                      }`}>
                        {val}
                      </span>
                      <div className={`w-10 h-5 rounded-full p-0.5 flex items-center transition-colors ${
                        isHigh ? 'bg-emerald-500 justify-end' : 'bg-gray-700 justify-start'
                      }`}>
                        <div className="w-4 h-4 rounded-full bg-white shadow-sm" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Current Computed Outputs */}
            <div className="mt-5 pt-4 border-t border-white/10">
              <div className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-2">
                Computed Circuit Outputs
              </div>
              <div className="grid grid-cols-2 gap-2">
                {circuit.outputs.map(out => {
                  const val = outputs[out.name] ?? 0;
                  const isHigh = val === 1;
                  return (
                    <div 
                      key={out.name}
                      className={`p-3 rounded-xl border text-center transition-all ${
                        isHigh ? 'bg-blue-500/15 border-blue-500/40 text-blue-300 shadow-sm' : 'bg-black/40 border-white/5 text-gray-400'
                      }`}
                    >
                      <div className="text-[10px] font-mono uppercase text-gray-400 truncate">{out.label}</div>
                      <div className="text-xl font-bold font-mono mt-0.5">{val}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Module 2: Logical Diagram & Waveforms (Col 5-12) */}
        <div className="lg:col-span-8 space-y-5">
          {/* Logical Diagram Container */}
          <div className="p-4 rounded-2xl bg-[#17181c] border border-white/10 shadow-md">
            <div className="flex items-center justify-between mb-3 border-b border-white/5 pb-2">
              <div className="flex items-center space-x-2">
                <Cpu size={16} className="text-blue-400" />
                <h3 className="text-xs font-bold text-gray-100 uppercase tracking-wider">
                  Logical Diagram ({circuit.name})
                </h3>
              </div>
              <div className="flex items-center space-x-2 text-[10px] text-gray-400 font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
                <span>High Signal (1)</span>
                <span className="w-2 h-2 rounded-full bg-gray-600 inline-block ml-2" />
                <span>Low Signal (0)</span>
              </div>
            </div>

            {/* Dynamic Interactive SVG Gate Diagram */}
            <div className="w-full bg-[#101114] rounded-xl p-4 border border-white/5 flex items-center justify-center min-h-[220px]">
              <svg viewBox="0 0 620 220" className="w-full max-w-2xl h-auto select-none">
                <defs>
                  <pattern id="logic-grid-2" width="20" height="20" patternUnits="userSpaceOnUse">
                    <circle cx="2" cy="2" r="0.8" fill="#333" />
                  </pattern>
                </defs>
                <rect width="620" height="220" fill="url(#logic-grid-2)" opacity="0.4" />

                {selectedCircuitId === '7476' ? (
                  /* JK Flip Flop Schematic */
                  <g>
                    {/* Input Wires */}
                    <text x="30" y="55" fill={inputs.J ? '#34d399' : '#9ca3af'} fontSize="12" fontWeight="bold" fontFamily="monospace">J = {inputs.J}</text>
                    <line x1="80" y1="50" x2="220" y2="50" stroke={inputs.J ? '#10b981' : '#4b5563'} strokeWidth={inputs.J ? '3' : '2'} strokeLinecap="round" />

                    <text x="30" y="115" fill={inputs.CLK ? '#34d399' : '#9ca3af'} fontSize="12" fontWeight="bold" fontFamily="monospace">CLK = {inputs.CLK}</text>
                    <line x1="100" y1="110" x2="220" y2="110" stroke={inputs.CLK ? '#10b981' : '#4b5563'} strokeWidth={inputs.CLK ? '3' : '2'} strokeLinecap="round" />

                    <text x="30" y="175" fill={inputs.K ? '#34d399' : '#9ca3af'} fontSize="12" fontWeight="bold" fontFamily="monospace">K = {inputs.K}</text>
                    <line x1="80" y1="170" x2="220" y2="170" stroke={inputs.K ? '#10b981' : '#4b5563'} strokeWidth={inputs.K ? '3' : '2'} strokeLinecap="round" />

                    {/* Top Preset & Bottom Clear */}
                    <text x="270" y="20" fill={inputs.PRE_n ? '#9ca3af' : '#ef4444'} fontSize="11" fontFamily="monospace">PRE_n = {inputs.PRE_n}</text>
                    <line x1="310" y1="25" x2="310" y2="35" stroke={inputs.PRE_n ? '#4b5563' : '#ef4444'} strokeWidth="2" />

                    <text x="270" y="210" fill={inputs.CLR_n ? '#9ca3af' : '#ef4444'} fontSize="11" fontFamily="monospace">CLR_n = {inputs.CLR_n}</text>
                    <line x1="310" y1="195" x2="310" y2="185" stroke={inputs.CLR_n ? '#4b5563' : '#ef4444'} strokeWidth="2" />

                    {/* Flip Flop Body Box */}
                    <rect x="220" y="35" width="180" height="150" rx="12" fill="#1e293b" stroke="#38bdf8" strokeWidth="2" />
                    <text x="310" y="70" fill="#38bdf8" fontSize="14" fontWeight="bold" textAnchor="middle">SN7476</text>
                    <text x="310" y="90" fill="#94a3b8" fontSize="10" textAnchor="middle">Dual JK Flip-Flop</text>
                    
                    {/* Clock Triangle */}
                    <path d="M 220,100 L 235,110 L 220,120" fill="none" stroke="#38bdf8" strokeWidth="2" />
                    
                    {/* Output Labels & Wires */}
                    <line x1="400" y1="65" x2="520" y2="65" stroke={outputs.Q ? '#38bdf8' : '#4b5563'} strokeWidth={outputs.Q ? '3' : '2'} strokeLinecap="round" />
                    <circle cx="520" cy="65" r="4" fill={outputs.Q ? '#38bdf8' : '#4b5563'} />
                    <text x="530" y="70" fill={outputs.Q ? '#38bdf8' : '#9ca3af'} fontSize="12" fontWeight="bold" fontFamily="monospace">Q = {outputs.Q}</text>

                    <line x1="400" y1="155" x2="520" y2="155" stroke={outputs.Q_bar ? '#38bdf8' : '#4b5563'} strokeWidth={outputs.Q_bar ? '3' : '2'} strokeLinecap="round" />
                    <circle cx="520" cy="155" r="4" fill={outputs.Q_bar ? '#38bdf8' : '#4b5563'} />
                    <text x="530" y="160" fill={outputs.Q_bar ? '#38bdf8' : '#9ca3af'} fontSize="12" fontWeight="bold" fontFamily="monospace">Q_bar = {outputs.Q_bar}</text>
                  </g>
                ) : (
                  /* Standard Logic Gate Schematic */
                  <g>
                    {/* Input A */}
                    <text x="50" y="75" fill={inputs.A ? '#34d399' : '#9ca3af'} fontSize="12" fontWeight="bold" fontFamily="monospace">A = {inputs.A}</text>
                    <line x1="90" y1="70" x2="250" y2="70" stroke={inputs.A ? '#10b981' : '#4b5563'} strokeWidth={inputs.A ? '3' : '2'} strokeLinecap="round" />

                    {/* Input B if exists */}
                    {circuit.signals.some(s => s.name === 'B') && (
                      <>
                        <text x="50" y="145" fill={inputs.B ? '#34d399' : '#9ca3af'} fontSize="12" fontWeight="bold" fontFamily="monospace">B = {inputs.B}</text>
                        <line x1="90" y1="140" x2="250" y2="140" stroke={inputs.B ? '#10b981' : '#4b5563'} strokeWidth={inputs.B ? '3' : '2'} strokeLinecap="round" />
                      </>
                    )}

                    {/* Central Gate Element */}
                    <g transform="translate(250, 60)">
                      <rect x="0" y="0" width="120" height="90" rx="10" fill="#1e293b" stroke="#38bdf8" strokeWidth="2" />
                      <text x="60" y="45" fill="#38bdf8" fontSize="13" fontWeight="bold" textAnchor="middle">{circuit.name.split(' ')[0]}</text>
                      <text x="60" y="65" fill="#94a3b8" fontSize="10" textAnchor="middle">Gate Core</text>
                    </g>

                    {/* Output Y */}
                    <line x1="370" y1="105" x2="480" y2="105" stroke={outputs.Y ? '#38bdf8' : '#4b5563'} strokeWidth={outputs.Y ? '3' : '2'} strokeLinecap="round" />
                    <circle cx="480" cy="105" r="5" fill={outputs.Y ? '#38bdf8' : '#4b5563'} />
                    <text x="495" y="110" fill={outputs.Y ? '#38bdf8' : '#9ca3af'} fontSize="14" fontWeight="bold" fontFamily="monospace">
                      Y = {outputs.Y}
                    </text>
                  </g>
                )}
              </svg>
            </div>
          </div>

          {/* Module 3 & 4: Truth Table & Live Waveforms */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Truth Table */}
            <div className="p-4 rounded-2xl bg-[#17181c] border border-white/10 shadow-md">
              <div className="flex items-center justify-between mb-3 border-b border-white/5 pb-2">
                <div className="flex items-center space-x-2">
                  <Table size={16} className="text-amber-400" />
                  <h3 className="text-xs font-bold text-gray-100 uppercase tracking-wider">
                    Excitation Truth Table
                  </h3>
                </div>
                <span className="text-[10px] text-amber-400 font-mono">AUTONOMOUS</span>
              </div>

              <div className="overflow-x-auto max-h-56">
                <table className="w-full text-xs text-left">
                  <thead className="text-[10px] text-gray-400 uppercase bg-black/40 font-mono">
                    <tr>
                      {Object.keys(circuit.truthTableRows[0].inputs).map(k => (
                        <th key={k} className="px-2 py-1.5 text-center">{k}</th>
                      ))}
                      {Object.keys(circuit.truthTableRows[0].outputs).map(k => (
                        <th key={k} className="px-2 py-1.5 text-center text-emerald-400">{k}</th>
                      ))}
                      <th className="px-2 py-1.5">Mode</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 font-mono text-[11px]">
                    {circuit.truthTableRows.map((row, idx) => {
                      // Check if matches current inputs
                      const isMatch = Object.entries(row.inputs).every(([k, v]) => inputs[k] === v);
                      return (
                        <tr 
                          key={idx}
                          className={`transition-colors ${
                            isMatch 
                              ? 'bg-emerald-500/20 text-emerald-300 font-bold border-l-2 border-emerald-400' 
                              : 'hover:bg-white/5 text-gray-400'
                          }`}
                        >
                          {Object.values(row.inputs).map((v, i) => (
                            <td key={i} className="px-2 py-1 text-center">{v}</td>
                          ))}
                          {Object.values(row.outputs).map((v, i) => (
                            <td key={i} className="px-2 py-1 text-center font-bold text-white">{v}</td>
                          ))}
                          <td className="px-2 py-1 text-[10px] text-gray-400 truncate">{row.mode || 'Active'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Live Waveform Traces */}
            <div className="p-4 rounded-2xl bg-[#17181c] border border-white/10 shadow-md flex flex-col">
              <div className="flex items-center justify-between mb-3 border-b border-white/5 pb-2">
                <div className="flex items-center space-x-2">
                  <Activity size={16} className="text-purple-400" />
                  <h3 className="text-xs font-bold text-gray-100 uppercase tracking-wider">
                    Digital Waveform Trace
                  </h3>
                </div>
                <span className="text-[10px] text-purple-400 font-mono">REAL-TIME</span>
              </div>

              <div className="flex-1 bg-[#101114] rounded-xl p-3 border border-white/5 flex flex-col justify-around min-h-[140px]">
                {/* Signals traces */}
                {circuit.signals.slice(0, 3).map(sig => {
                  const val = inputs[sig.name] ?? 0;
                  return (
                    <div key={sig.name} className="flex items-center space-x-2">
                      <span className="w-12 text-[10px] font-mono text-gray-400">{sig.name}:</span>
                      <div className="flex-1 h-5 flex items-center">
                        <svg className="w-full h-full">
                          <polyline
                            points={`0,${val ? '2' : '16'} 30,${val ? '2' : '16'} 60,${val ? '2' : '16'} 90,${val ? '2' : '16'} 120,${val ? '2' : '16'} 150,${val ? '2' : '16'} 200,${val ? '2' : '16'}`}
                            fill="none"
                            stroke={val ? '#10b981' : '#4b5563'}
                            strokeWidth="2"
                          />
                        </svg>
                      </div>
                      <span className={`text-[10px] font-mono font-bold ${val ? 'text-emerald-400' : 'text-gray-500'}`}>
                        {val}
                      </span>
                    </div>
                  );
                })}

                {/* Primary Output trace */}
                {circuit.outputs.slice(0, 2).map(out => {
                  const val = outputs[out.name] ?? 0;
                  return (
                    <div key={out.name} className="flex items-center space-x-2 pt-1 border-t border-white/5">
                      <span className="w-12 text-[10px] font-mono text-blue-400 font-bold">{out.name}:</span>
                      <div className="flex-1 h-5 flex items-center">
                        <svg className="w-full h-full">
                          <polyline
                            points={`0,${val ? '2' : '16'} 30,${val ? '2' : '16'} 60,${val ? '2' : '16'} 90,${val ? '2' : '16'} 120,${val ? '2' : '16'} 150,${val ? '2' : '16'} 200,${val ? '2' : '16'}`}
                            fill="none"
                            stroke={val ? '#38bdf8' : '#4b5563'}
                            strokeWidth="2.5"
                          />
                        </svg>
                      </div>
                      <span className={`text-[10px] font-mono font-bold ${val ? 'text-blue-400' : 'text-gray-500'}`}>
                        {val}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
